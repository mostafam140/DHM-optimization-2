function [ popVar_out , I_sort ] = PSO_alg( x_old_in , omega , ghj)

global v_old  w_dense  func  obj_num  Pbest  d1_bestp  Gbest  d1_bestg ...
       var_num  Total_best_F_Comp  X_Total  Pareto_sol  gen  ub  lb  pop_size  p3

% c1 = 0.5 ;      c2 = 0.5 ;

for i = 1 : size(x_old_in , 1)

%         x_old_in(i,1:var_num) = [0 9 6 -0.4288 -0.1424 0.0395] ;  %
%         corresponding to Loperz answer

        [f_val, g, x] = func(obj_num(1), x_old_in(i,1:var_num)) ;
        
        figure(1)
        
        p3 = plot(f_val(1), 2-f_val(2),'o','LineWidth',1,...
                'MarkerEdgeColor','g',... %                'MarkerFaceColor','y',...
                'MarkerSize',5) ;
            
                if 2-f_val(2) < 1
                    
                    plot(f_val(1), 2-f_val(2),'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...  %                     'MarkerFaceColor','r',...
                    'MarkerSize',5) ;
                    
                end
                                
%         xlim([1300  2000])
%         ylim([0.5  3])

        set(gca,'FontName','Times New Roman','FontSize',13) ;
        
        xlabel('weight (kg)','FontName','Times New Roman','FontSize',13)
        ylabel('\lambda (buckling factor)','FontName','Times New Roman','FontSize',13)
        
        pause (0.1)
        
        hold on
        
        grid on
               
        
        for i_w = 1 : size(w_dense,1)
            
%             cos_th = (f_val*w_dense(i_w,:)') / (norm(f_val)*norm(w_dense(i_w,:))) ;
            
%             theta = acosd(cos_th) ;
            deltax = abs(f_val(1,1)-w_dense(i_w,1)) ;
            
            if mod(gen , 50) == 0
                fprintf('  gen = %10.0f\n' , gen )
            end
            
%             if theta < (90/(size(w_dense,1)-1))
            if deltax <= 0.5*abs(w_dense(2,1)-w_dense(1,1))  %  0.013
                
                Pro_f_on_w = f_val(1,2) ; %  f_val*w_dense(i_w,:)' ;        % Pro_f_on_w is the projection of f_val on w_dense 
                
                if Pro_f_on_w < d1_bestp(i)
                    
                    d1_bestp(i) = Pro_f_on_w ;
                    Pbest(i,1:var_num) = x_old_in(i,1:var_num) ;
                    
                end
                
                if ( Pro_f_on_w < d1_bestg(i_w)) % &&  d2_cc(i,ghj) < min(d1_cc(i,ghj),d2_bestg(ghj))   % && ( d2_cc(i,ghj) < d2_bestg(i) )
                    
                    d1_bestg(i_w) = Pro_f_on_w ;
                    Gbest(i_w,1:var_num) = x_old_in(i,1:var_num) ;
                    
                    Pareto_sol(i_w,:) = f_val ;                     
                                        
                end
                
                if Pro_f_on_w < Total_best_F_Comp
                    
                    X_Total(i_w,1:var_num) = x_old_in(i,:) ;
                    Total_best_F_Comp = Pro_f_on_w ;
                    
                end
                
                
%                 %%                               Mutation
% 
%                     num_affected = randi(var_num) ; % ceil(var_num*(1-sqrt(gen/Gen_max))) ;
% 
%                     affected_inices = randperm(var_num,num_affected) ;
% 
%                     for i_num_popsize = 1 : ceil(0.1*pop_size)    %   ceil(pop_size*(1-sqrt(gen/Gen_max)))
% 
%                         popVar_in(i_num_popsize,:) = Gbest(i_w,1:var_num) ;
% 
%                         for i_mut = 1 : num_affected
% 
%                             whichdim = affected_inices(i_mut) ;      % randi(var_num) ;
% 
%                             mutrate = 0.5 ;
% 
%                             mutrange = (ub(whichdim) - lb(whichdim))*((1-gen/Gen_max)^(5/mutrate)) ;
% 
% %                             ub_mut = popVar_in(whichdim) + mutrange ;
% %                             lb_mut = popVar_in(whichdim) - mutrange ;
% 
%             %                 if lb_mut < lb(whichdim)
%                                 lb_mut = lb(whichdim) ;
%             %                 end
% 
%             %                 if ub_mut > ub(whichdim)
%                                 ub_mut = ub(whichdim) ;
%             %                 end
% 
%                             x_old_in(i_num_popsize, whichdim) = rand*(ub_mut-lb_mut) + lb_mut ;
% 
%                         end           
%                         
%                     end                                
        
                break                
                
            end
            
        end
        
% %         if ( F_Comp_alg(i) < d1_bestp(i) )          comented on 97-5-23
% %             
% %             d1_bestp(i) = F_Comp_alg(i) ;
% %             Pbest(i,1:var_num) = x_old_in(i,1:var_num) ;
% %             
% %         end
% %         
% %         if ( F_Comp_alg(i) < d1_bestg(ghj)) % &&  d2_cc(i,ghj) < min(d1_cc(i,ghj),d2_bestg(ghj))   % && ( d2_cc(i,ghj) < d2_bestg(i) )
% %             
% %             d1_bestg(ghj) = F_Comp_alg(i) ;                        
% %             Gbest(ghj,1:var_num) = x_old_in(i,1:var_num) ;
% %         end
% %         
% %         if F_Comp_alg(i) < Total_best_F_Comp            
% %             X_Total(ghj,1:var_num) = x_old_in(i,:) ;
% %             Total_best_F_Comp = F_Comp_alg(i) ;            
% %         end
            
	
%     end
    
    Randd = randperm(var_num) ;

    for j = 1 : size(x_old_in , 2)        % size(x_old_in,2) = var_num                
        
        rang = size(Gbest,1) ;

        gBest = randperm(rang) ;            gBest_indx = gBest(1) ;

% size(Gbest)
% size(x_old_in)
%         v_new(i,j) = omega*v_old(i,j) + c1*rand*(Pbest(i,j)-x_old_in(i,j)) + c2*rand*(Gbest(ghj,j)-x_old_in(i,j)) ;
        phi1 = 2.05*rand(1) ;    phi2 = 2.05*rand(1) ;
        
        v_new(i,j) = omega*( v_old(i,j) + phi1*(Pbest(i,j)-x_old_in(i,j)) + phi2*(Gbest(gBest_indx,j)-x_old_in(i,j)) ) ;
%         if j > Randd(1) && gen > Gen_max/2
%             v_new(i,j) = 0 ;
%         end
        
        popVar_out(i,j) = x_old_in(i,j) + v_new(i,j)*1 ;
        
        if popVar_out(i,j) < 0
            
            r = 1-(popVar_out(i,j)/min(popVar_out(:,j))) ;
            if r < 0
                r
                input('1')
            end
            popVar_out(i,j) = 0 + r ; % rand/2 ;    % Changed on 97-3-30
            
        elseif popVar_out(i,j) > 1
            
            r = 1-(popVar_out(i,j)/max(popVar_out(:,j))) ;
            if r > 1
                r
                input('2')
            end
            popVar_out(i,j) = 1 - r ; % (rand+1)/2 ;   % Changed on 97-3-30
            
        end
                
    end
    
end


% Added on 97-5-29
for i = 1 : pop_size
    
    for j = 1 : 3
        
        if ( ( x_old_in(i,j) + v_new(i,j) ) < lb(j))
            
            popVar_out(i,j) = lb(j) ;
        
        elseif ( ( x_old_in(i,j) + v_new(i,j) ) > ub(j))
            
            popVar_out(i,j) = ub(j) ;
            
        else
            
            popVar_out(i,j) = round(x_old_in(i,j) + v_new(i,j)) ;
            
        end
        
    end
    
    for j = 4 : 6
        if ( ( x_old_in(i,j) + v_new(i,j) ) < -1)
            popVar_out(i,j) = -1 ;
        elseif ( ( x_old_in(i,j) + v_new(i,j) ) > 1)
            popVar_out(i,j) = 1 ;
        else
            popVar_out(i,j) = x_old_in(i,j) + v_new(i,j) ;
        end             
    end
    
    [Cons_LP, C_AD] = nlcon_mo(popVar_out(i,:)) ;             
    Cons = max(Cons_LP,C_AD) ;
    
    if ( Cons <= 0 ) % && ( C_AD <= 0 )
        popVar_out(i,:) = popVar_out(i,:) ;                 % No change
    else
        popVar_out(i,:) = x_old_in(i,:) ;      % Constraint is violated
    end
    
%     [Obje(1)  Obje(2) lambda] = Obj_f(i,popVar_out) ;   % Obje(1): Weight, Obje(2): Buckling load factor (Objective functions)        
%     
%     Pop_fit(i,1) = Obje(1) ;
%     Pop_fit(i,2) = Obje(2) ;
%     Pop_fit(i,3) = lambda ;
    
end


[~,I_sort] = sort(Pro_f_on_w) ;


v_old = v_new ;

end



    


