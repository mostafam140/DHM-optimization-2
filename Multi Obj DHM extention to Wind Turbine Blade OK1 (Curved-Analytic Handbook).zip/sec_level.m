function [ Stack_Seq, Lam_diff_gbest ] = sec_level(i_g, popVar_in)

global  U  th  rho  a_r  b_s  sigma_2  sigma_3  sigma_4  sigma_5  sigma_6  E1  E2  E3  G12  G13  G23  NU21  NU23  NU31  ...
        Q  N_x  N_y  N_xy  func_count  func_count_sec_lev

Theta_t = [] ;

NN(1) = popVar_in(i_g,1) ;
NN(2) = popVar_in(i_g,2) ;
NN(3) = popVar_in(i_g,3) ;

popsize_sec = 25 ;      Gen_max_sec = 8 ;

func_count_sec_lev = popsize_sec*Gen_max_sec ;

c1_sec = 1 ;            c2_sec = 1 ;

% popVar_in(i_g,:)

maxvar_sec = round(popVar_in(i_g, 1) + popVar_in(i_g, 2) + popVar_in(i_g, 3)) ;

%% Initialize population with random values

Lam_diff_gbest = 1000 ;
        
for gen_sec = 1 : Gen_max_sec   

for i_sec = 1 : popsize_sec
    
    if gen_sec == 1        
        
        popVar_sec(i_sec, :) = randperm(round(maxvar_sec)) ; % randsrc(popsize, n, de) ;    %  [1 4 2 9 5 8 3 6 7 12 10 11] ;
        
        Pbest_par_sec(i_sec,:) = popVar_sec(i_sec, :) ;
        
        v_new_sec(i_sec, 1:maxvar_sec) = 0 ;
        
        for ii_sec = 1 : i_sec-1
        
            if popVar_sec(i_sec,:) == popVar_sec(ii_sec,:)

                i_sec = i_sec - 1 ;
    %             break
            end
            
        end
        
        Lam_diff_min(i_sec) = 1000 ;
        
    else                
        
        omega = 0.9 - (0.5)*(gen_sec/Gen_max_sec) ;
        
        popVar_old_sec(i_sec,:) = popVar_sec(i_sec,:) ;
        
        v_old_sec(i_sec,:) = v_new_sec(i_sec,:) ;
        
%         popVar_sec = PSO_alg(popVar_old , Gbest_par , Pbest_par , omega , Nei_Ref_of_particle_i) ;
        
        
%         Gbest_Inds = Nei_Ref_of_particle_i(i) ;       % It means that particle i belongs to Reference Direction Gbest_Inds
    
        popVar_sec(i_sec,:) = popVar_old_sec(i_sec,:) ;
        
        for j_sec = 1 : size(popVar_sec , 2)
%             size(v_new_sec)
%             size(v_old_sec)
%             size(Pbest_par_sec)
%             size(popVar_old_sec)
%             size(Gbest_par_sec)

            v_new_sec(i_sec,j_sec) = omega*v_old_sec(i_sec,j_sec) + c1_sec*rand*(Pbest_par_sec(i_sec,j_sec)-popVar_old_sec(i_sec,j_sec)) + c2_sec*rand*(Gbest_par_sec(1,j_sec)-popVar_old_sec(i_sec,j_sec)) ;
            
            v_new_sec(i_sec,j_sec) = round(v_new_sec(i_sec,j_sec)) ;
%             popVar_sec(i_sec,j_sec) = popVar_old_sec(i_sec,j_sec) + round(v_new_sec(i_sec,j_sec))*1 ;
            
            if v_new_sec(i_sec,j_sec) < 1
                v_new_sec(i_sec,j_sec) = randi(round(maxvar_sec/2)) ;
            elseif v_new_sec(i_sec,j_sec) > maxvar_sec
                v_new_sec(i_sec,j_sec) = randi(maxvar_sec) ;
            end
            
            
            for jj_sec = 1 : size(popVar_sec , 2)
            
                if popVar_sec(i_sec,jj_sec) == v_new_sec(i_sec,j_sec)
                
                    tempp = popVar_sec(i_sec,j_sec) ;
                    
                    popVar_sec(i_sec,j_sec) = popVar_sec(i_sec,jj_sec) ;
        
                    popVar_sec(i_sec,jj_sec) = tempp ;
                
                    break
                
                end
            
            end                              
            
        end               
                
    end

    x_x = popVar_sec(i_sec,:) ;

    kkk = 1 ;   sgn = 0 ;    

    siz_Popvar = size(x_x,2) ;
    
    for kk_sec = 1 : siz_Popvar

        if (x_x(kk_sec) < (popVar_in(i_g,1)+1))
        
            Theta_t(kkk) = 0 ;

        elseif (x_x(kk_sec) < (popVar_in(i_g,1)+popVar_in(i_g,2)+1) )

            Theta_t(kkk) = 45 ;
            Theta_t(kkk+1) = -45 ;      kkk = kkk + 1 ;

        else

            Theta_t(kkk) = 90 ;

        end
        
        kkk = kkk + 1 ;
        
    end    
    
if isempty (Theta_t)
    
    popVar_sec
    x_x
    i_g
    popVar_in(i_g,:)
    
    input('sec_level.m, line 142')
    
end

    all_ang_u_s = Theta_t ;       % _s denotes symmetric
    
    symet = size(all_ang_u_s,2) ;

    all_ang_u(1:symet) = all_ang_u_s ;

    all_ang_u((2*symet):-1:(symet+1)) = all_ang_u_s ;   % u denotes upper panels
    
    all_ang = all_ang_u ;  % Lopez: [90  90  45 -45  45 -45  90  90  45 -45  90  90  45 -45  45 -45  45 -45  45 -45  45 -45  45 -45 ...
%      -45 45  -45 45  -45 45  -45 45  -45 45  -45 45  90  90  -45 45 90  90  -45 45  -45 45  90  90] % 


    N_sec = length(all_ang) ;

    h = zeros(N_sec+1,1) ;
    h(N_sec+1) = N_sec*th/2 ;

    Xi_1_D = 0 ;    Xi_2_D = 0 ;    Xi_3_D = 0 ;    Xi_4_D = 0 ;
    
    for k_sec = 1 : N_sec
        h(k_sec) = (k_sec - N_sec/2 - 1)*th ;
    end
    
    for k = 1 : N_sec    
        Xi_1_D = Xi_1_D + 0.5*cosd(2*all_ang(k))*(h(k+1)^3 - h(k)^3) ;
        Xi_2_D = Xi_2_D + 0.5*cosd(4*all_ang(k))*(h(k+1)^3 - h(k)^3) ;
        Xi_3_D = Xi_3_D + 0.5*sind(2*all_ang(k))*(h(k+1)^3 - h(k)^3) ;
        Xi_4_D = Xi_4_D + 0.5*sind(4*all_ang(k))*(h(k+1)^3 - h(k)^3) ;
    end

    Xi_1_D = (8/((N_sec*th)^3))*Xi_1_D ;     Xi_2_D = (8/((N_sec*th)^3))*Xi_2_D ;
    Xi_3_D = (8/((N_sec*th)^3))*Xi_3_D ;     Xi_4_D = (8/((N_sec*th)^3))*Xi_4_D ;
    
    xi_1_D = Xi_1_D ;       xi_2_D = Xi_2_D ;
    xi_3_D = Xi_3_D ;
    
    DD = [1  xi_1_D    xi_2_D  0  0
              1  -xi_1_D   xi_2_D  0  0
              0  0        -xi_2_D  1  0
              0  0        -xi_2_D  0  1
              0  xi_3_D/2  0       0  0
              0  xi_3_D/2  0       0  0] ;
           
            D_temp = zeros(6,1);
            
            D_temp = DD*U ;

            D = zeros(3,3);

            H = 2*( NN(1) + 2*NN(2) + NN(3) )*th ;   % 2 is added to consider the symmetric Stack            
            
            D = ((H^3)/12)*[D_temp(1)  D_temp(3)   D_temp(5)          %  H: plate thickness
                            D_temp(3)  D_temp(2)   D_temp(6)
                            D_temp(5)  D_temp(6)   D_temp(4)] ;
            
%             AA = [1  xi_1_A     xi_3_A   0  0
%                   1  -xi_1_A    xi_3_A   0  0
%                   0  0         -xi_3_A   1  0
%                   0  0         -xi_3_A   0  1
%                   0  xi_2_A/2   xi_4_A   0  0
%                   0  xi_2_A/2  -xi_4_A   0  0] ;

%             A_temp = zeros(6,1);
%             A_temp = AA*U ;

%             A = zeros(3,3);

%             A = (H)*[A_temp(1)  A_temp(3)   A_temp(5)          %  H: plate thickness
%                  A_temp(3)  A_temp(2)   A_temp(6)
%                  A_temp(5)  A_temp(6)   A_temp(4)] ;

%             A = A/1000 ;
            D = D/1000 ;
            
            
%             Eq29 = -min(min(A)) ;
            Eq30 = -min(min(D)) ;                        
            
            C_AD = Eq30 ;   %  max(Eq29 , Eq30) ;
    
            Cons = -1 ; %    C_AD = -1 ;
            
%             if ( Cons <= 0 ) && ( C_AD <= (1e-6) )    % in the second level, due to computational errors (from rounding or approximations) some elemnts of A or D bacome -1e-12  ;                
% 
%                     % Axial buckling factor
%                     for mm = 1 : 15
% 
%                         for nn = 1 : 15
%                             
%                             lambda1(mm,nn) = ( D(1,1)*((mm/a_r)^4) + 2*(D(1,2)+2*D(3,3))*((mm/a_r)^2)*((nn/b_s)^2)+D(2,2)*((nn/b_s)^4) ) / ( ((mm/a_r)^2)*N_x +((nn/b_s)^2)*N_y ) ;
%                             lambda1(mm,nn) = lambda1(mm,nn)*(pi^2) ;
%                             
%                         end
%                     end
%                   
%                     pf(2) = 2-min(min(abs(lambda1))) ;
%             else             
%                 
%                 fprintf('constraints are violated, sec_level.m, line 240')
% %                 input('constraints are violated, Wei_Buc, line 234')
%                 
%                 pf(2) = 2 ;    % 90 ;
%             end
                                                
    
    Lam_diff(i_sec) = (popVar_in(i_g,4)-Xi_1_D)^2 + (popVar_in(i_g,5)-Xi_2_D)^2 + (popVar_in(i_g,6)-Xi_3_D)^2 ;   %  pf(2) ; %  Commented 
    
    if Lam_diff(i_sec) < Lam_diff_min(i_sec)
        
        Lam_diff_min(i_sec) = Lam_diff(i_sec) ;
        
        Pbest_par_sec(i_sec,:) = popVar_sec(i_sec,:) ;
        
    end
    
    if Lam_diff(i_sec) < Lam_diff_gbest
        
        Lam_diff_gbest = Lam_diff(i_sec) ;
        
        Gbest_par_sec = popVar_sec(i_sec,:) ;
        
        Stack_Seq = all_ang ;        
            
    end
    

    
end

% fprintf(' \n  generation = %3.0f \n ' , gen_sec )
% input('------------------------ line 157 ----------------')

end


end

