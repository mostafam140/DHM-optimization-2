function [sigma_p, popVar_out_p] = PSO_alg_Curved_2()

global  P_best  p_best_v  G_best  g_best  n  psi_g

v_old = [] ;          popVar = [] ;

Gen_max = 1000 ;      pop_size = 550 ;

var_num = 3 ;        v_old(1:pop_size, 1:var_num) = rand(pop_size,var_num) ;

lb = [-10  -10  -10] ;   ub = [10  15  15] ;


popVar = rand(pop_size, var_num) ;        % 3: The number of variables
% popVar(1,:) = [0.5982     0.035103      0.64575] ;

% rand(pop_size,1).*(ub-lb) + lb ;  % 
p_best_v = popVar ;


for i = 1 : pop_size
    
    lambda = popVar(i,1) ;     alpha = popVar(i,2) ;     beta = popVar(i,3) ;       % lambda = m*psi*r/L ;       
    
    x_x = [lambda, alpha, beta] ;
    
    Obj(i) = Obj_buc_Curved_4(x_x) ;         % Obj(i): critical (buckling) stress [MPa]
    
    P_best(i) = Obj(i) ;
            
    p_best_v(i,1:var_num) = popVar(i,1:var_num) ;
    
end


% fprintf(' G_best (initial) =  %7.0f    \n\n' , min(Obj))

% input('PSO_alg, line 37')

G_best = Obj(pop_size) ;

% if psi_g == 0.1
                
    g_best(1,1:var_num) = popVar(pop_size,1:var_num) ;
    
% end
        
MSInd = 0 ;            % Multi-Start Index

for gen = 1 : Gen_max
    
    for i = 1 : pop_size
        
        lambda = popVar(i,1) ;     alpha = popVar(i,2) ;     beta = popVar(i,3) ;       % lambda = m*psi*r/L ;        
        
        x_x = [lambda, alpha, beta] ;
        
        Obj(i) = Obj_buc_Curved_4(x_x) ;
        
        if ( Obj(i) < P_best(i) )
            
            P_best(i) = Obj(i) ;
            
            p_best_v(i,1:var_num) = popVar(i,1:var_num) ;
            
        end
            
        if ( Obj(i) < G_best )
            
            G_best = Obj(i) ;
                
            g_best(1,1:var_num) = popVar(pop_size,1:var_num) ;                         
            
        end
        
        G_best_MS(gen) = G_best ;
            
                            
        for j = 1 : var_num

            phi1 = 2.05*rand ;    phi2 = 2.05*rand ;    omega = 0.7298 ;
            
            v_new(i,j) = omega*( v_old(i,j) + phi1*(p_best_v(i,j)-popVar(i,j)) + phi2*(g_best(1,j)-popVar(i,j)) ) ;

            popVar(i,j) = popVar(i,j) + v_new(i,j)*1 ;

            if popVar(i,1) < 0

                popVar(i,1) = rand/2 ;    % Changed on 97-3-30

            end

        end

    end
    
    
%%                               Multi-Start Strategy
    
%     MSCrit = 200*(1-0.5*gen/Gen_max) ;
        
    MSInd = MSInd + 1 ;
    
    if (MSInd > 50)  &&  abs(G_best_MS(gen-34)-G_best_MS(gen-1)) < 0.1
                
                MSInd = 0 ;
                
%                 fprintf('\n --  Re-Initialization  --  -- Re-Initialization  --  --  Re-Initialization  -- \n')  Commented on 98-3-3
%                        
%                 f_min = 500*ones(1,obj_num) ;        f_max = zeros(1,obj_num) ;
%                popVar = popVar_in ;
                
                popVar = rand(pop_size, var_num) ; 
%                 popVar = rand(pop_size,var_num) ;
                
                p_best_v(1:ceil(0.5*pop_size),1:var_num) = popVar(1:ceil(0.5*pop_size),:) ; %1000 ;
%                 g_best(1,1:var_num) = popVar(1,1:var_num) ; %1000 ;
                
                P_best(1:1:ceil(0.5*pop_size)) = 10000 ;
%                 G_best = 10000 ;
                
                
%                 d1_bestg(w_ind) = 1000 ;
%                 d2_bestg(w_ind) = 1000 ;
%                 d1_bestp(1:pop_size) = 1000 ;
%                 d2_bestp(1:pop_size) = 1000 ;
                v_old(1:ceil(0.5*pop_size),1:var_num) = rand(ceil(0.5*pop_size),var_num) ;
            end
            
    
    %%                               Mutation

        num_affected = randi(var_num) ; % ceil(var_num*(1-sqrt(gen/Gen_max))) ;
        
        affected_inices = randperm(var_num,num_affected) ;
        
        for i_num_popsize = 1 : ceil(0.1*pop_size)    %   ceil(pop_size*(1-sqrt(gen/Gen_max)))
            
            popVar_in(i_num_popsize,:) = g_best(1,1:var_num) ;
            
            for i_mut = 1 : num_affected
                
                whichdim = affected_inices(i_mut) ;      % randi(var_num) ;
                
                mutrate = 0.5 ;

                mutrange = (ub(whichdim) - lb(whichdim))*((1-gen/Gen_max)^(5/mutrate)) ;
                
                ub_mut = popVar_in(whichdim) + mutrange ;
                lb_mut = popVar_in(whichdim) - mutrange ;
                
%                 if lb_mut < lb(whichdim)
                    lb_mut = lb(whichdim) ;
%                 end
                
%                 if ub_mut > ub(whichdim)
                    ub_mut = ub(whichdim) ;
%                 end                                
                
                popVar(i_num_popsize, whichdim) = rand*(ub_mut-lb_mut) + lb_mut ;
                
%                 if popVar(i_num_popsize,1) < 0

%                     popVar(i_num_popsize,1) = rand/2 ;    % Changed on 97-3-30

%                 end
            
                
            end
            
            
        end
        
%     if mod(gen,200) == 0
%         fprintf(' G_best(gen =   %3.0f , psi = %5.3f , ) =   %7.0f   \n' , gen , psi_g, G_best)    %  Commented on 98-3-3
%     end
    
end

v_old = v_new ;

sigma_p = G_best ;

% % fprintf(' psi =  %3.2f    critical stress(MPa)    = %7.0f   \n' , psi_g , G_best)

popVar_out_p = g_best ;

% input('PSO_alg Finished --------------, line 179')

end



    


