function [Cons_LP, C_AD] = nlcon_mo(NN)

clear Cons_LP  C_AD
global U  th  rho  Q

% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 

%     for ii = 1 : 3        
        
        xi_1_A = (NN(1)-NN(3))/(NN(1)+NN(3)+2*NN(2)) ;
        xi_2_A = 0 ;
        xi_3_A = (NN(1)+NN(3)-2*NN(2))/(NN(1)+NN(3)+2*NN(2)) ;
        xi_4_A = 0 ;
        
%         Cons = 1 ;
%         W_limit = 0 ;
%         count_l = 0 ; 
                
%         while ( (Cons > W_limit) )
            
%             count_l = count_l + 1 ;
%             
%              % Virtual Constraints, Because for sum combinations of number of plies, constraints
%              % are not satisfied even after several iterations, So W_limit set a little greater than 0.
%             if (count_l > 10000)
%                 W_limit = 0.000005*count_l ;
%             end
            
            xi_1_D = NN(4) ;
            xi_2_D = NN(5) ;
            xi_3_D = NN(6) ;
            xi_4_D = 0 ;

            Eq1 = (xi_1_A-1)^4 - 4*(xi_1_D-1)*(xi_1_A-1) ;      % Ref: Liu, Toropov 2015, Eq 3
            Eq2 = (xi_2_A-1)^4 - 4*(xi_2_D-1)*(xi_2_A-1) ;
            Eq3 = (xi_3_A-1)^4 - 4*(xi_3_D-1)*(xi_3_A-1) ;

            Eq4 = (xi_1_A+1)^4 - 4*(xi_1_D+1)*(xi_1_A+1) ;
            Eq5 = (xi_2_A+1)^4 - 4*(xi_2_D+1)*(xi_2_A+1) ;
            Eq6 = (xi_3_A+1)^4 - 4*(xi_3_D+1)*(xi_3_A+1) ;

            Eq7 = (2*xi_1_A-xi_3_A-1)^4 - 16*(2*xi_1_D-xi_3_D-1)*(2*xi_1_A-xi_3_A-1) ;
            Eq8 = (2*xi_1_A+xi_3_A+1)^4 - 16*(2*xi_1_D+xi_3_D+1)*(2*xi_1_A+xi_3_A+1) ;
            Eq9 = (2*xi_1_A-xi_3_A+3)^4 - 16*(2*xi_1_D-xi_3_D+3)*(2*xi_1_A-xi_3_A+3) ;

            Eq10 = (2*xi_1_A + xi_3_A - 3)^4 - 16*(2*xi_1_D+xi_3_D-3)*(2*xi_1_A+xi_3_A-3) ;
            Eq11 = (2*xi_2_A - xi_3_A + 1)^4 - 16*(2*xi_2_D-xi_3_D+1)*(2*xi_2_A-xi_3_A+1) ;
            Eq12 = (2*xi_2_A + xi_3_A + 1)^4 - 16*(2*xi_2_D+xi_3_D-1)*(2*xi_2_A+xi_3_A-1) ;

            Eq13 = (2*xi_2_A - xi_3_A - 3)^4 - 16*(2*xi_2_D-xi_3_D-3)*(2*xi_2_A-xi_3_A-3) ;
            Eq14 = (2*xi_2_A + xi_3_A + 3)^4 - 16*(2*xi_2_D+xi_3_D+3)*(2*xi_2_A+xi_3_A+3) ;
            Eq15 = (xi_1_A - xi_2_A - 1)^4 - 4*(xi_1_D-xi_2_D-1)*(xi_1_A-xi_2_A-1) ;

            Eq16 = (xi_1_A + xi_2_A + 1)^4 - 4*(xi_1_D+xi_2_D+1)*(xi_1_A+xi_2_A+1) ;
            Eq17 = (xi_1_A - xi_2_A + 1)^4 - 4*(xi_1_D-xi_2_D+1)*(xi_1_A-xi_2_A+1) ;
            Eq18 = (xi_1_A + xi_2_A - 1)^4 - 4*(xi_1_D+xi_2_D-1)*(xi_1_A+xi_2_A-1) ;

            Eq19 = 2*(1+xi_3_D)*(xi_2_D^2) - 4*(xi_1_D*xi_2_D*xi_4_D) + (xi_4_D^2) - (xi_3_D-2*(xi_1_D^2)+1)*(1-xi_3_D) ;    % Ref: Liu, Toropov 2015, Eq 2
            Eq20 = xi_1_D^2 + xi_2_D^2 - 1 ;
            Eq21 = 2*(xi_1_D^2) - 1 - xi_3_D ;
            Eq22 = xi_3_D - 1 ;

            Eq23 = xi_1_D - (1 - ( (NN(3)+2*NN(2))^3 + NN(3)^3 )/((NN(1)+2*NN(2)+NN(3))^3) ) ;    % Ref: Liu, Toropov 2015, Eq 7
            Eq24 = ( ( (NN(1)+2*NN(2))^3 + NN(1)^3 )/((NN(1)+2*NN(2)+NN(3))^3) - 1 ) - xi_1_D ;

            Eq25 = xi_2_D - (1 + ( (NN(3)+NN(1))^3 - 2*((NN(3)+NN(2)+NN(1))^3) )/((NN(1)+NN(3)+2*NN(2))^3) ) ;    % Ref: Liu, Toropov 2015, Eq 8
            Eq26 = 1.5*( 4*(NN(2)^2)/((NN(1)+2*NN(2)+NN(3))^3) ) - xi_2_D ;

            Eq27 = xi_3_D - ( 1 - (2*((2*NN(2))^3))/((NN(1)+2*NN(2)+NN(3))^3) ) ;    % Ref: Liu, Toropov 2015, Eq 9
            Eq28 = ( ( 2*((NN(1)+NN(3))^3))/((NN(1)+2*NN(2)+NN(3))^3 ) -1)  - xi_3_D ;
   
            
            DD = [1  xi_1_D    xi_2_D  0  0
              1  -xi_1_D   xi_2_D  0  0
              0  0        -xi_2_D  1  0
              0  0        -xi_2_D  0  1
              0  xi_3_D/2  0       0  0
              0  xi_3_D/2  0       0  0] ;
           
            D_temp = zeros(6,1);
            
            D_temp = DD*U ;

            D = zeros(3,3);

            H = 2*( NN(1) + 2*NN(2) + NN(3) )*th ;   % 2 is added to consider the symmetric Stack            
            
            D = ((H^3)/12)*[D_temp(1)  D_temp(3)   D_temp(5)          %  H: plate thickness
                            D_temp(3)  D_temp(2)   D_temp(6)
                            D_temp(5)  D_temp(6)   D_temp(4)] ;
            
            AA = [1  xi_1_A     xi_3_A   0  0
                  1  -xi_1_A    xi_3_A   0  0
                  0  0         -xi_3_A   1  0
                  0  0         -xi_3_A   0  1
                  0  xi_2_A/2   xi_4_A   0  0
                  0  xi_2_A/2  -xi_4_A   0  0] ;

            A_temp = zeros(6,1);
            A_temp = AA*U ;

            A = zeros(3,3);

            A = (H)*[A_temp(1)  A_temp(3)   A_temp(5)          %  H: plate thickness
                 A_temp(3)  A_temp(2)   A_temp(6)
                 A_temp(5)  A_temp(6)   A_temp(4)] ;

            A = A/1000 ;
            D = D/1000 ;
         
            Eq29 = -min(min(A)) ;
            Eq30 = -min(min(D)) ;                     
            
            C = [Eq1  Eq2  Eq3  Eq4  Eq5  Eq6  Eq7  Eq8  Eq9  Eq10  Eq11 Eq12  Eq13  Eq14  Eq15  Eq16 ...
                 Eq17  Eq18  Eq19  Eq20  Eq21  Eq22  Eq23  Eq24  Eq25  Eq26  Eq27 Eq28 ] ;
                
            Cons_LP = max(C) ;
            
            C_AD = max(Eq29 , Eq30) ;
            
%        while end (line 55)
                         
%              lambda_tem(ii) = Run_ANSYS_file(A,D) ;
             
                              %%%%%%%%%%%   Should be Comletted  %%%%%%%%%%%%%%%
%                  fprintf('\n');
%                  fprintf('    N_T = %6.1f    ([ %6.1f %6.1f %6.1f ]s)   %6.3f  %6.3f  %6.3f ' , ...
%                      2*(NN(1)+2*NN(2)+NN(3)) , NN(1) , NN(2) , NN(3) ,  xi_1_D , xi_2_D , xi_3_D )
%                  fprintf('\n');
%                  fprintf('\n');
%                  fprintf('    lambda = %6.3f ' , lambda_tem )
%                  fprintf('\n');     
                 
%    for end (line 45)
    
%     [lambda2_srtd rInd] = sort(lambda_tem) ;
    
%     IoME = Ind(3) ;      % IoME: Index of Minimum Effect
    
%     if (IoME == 1 || IoME == 3)
%         
%         if ( ub(IoME) < 0.1*(ub(1)+2*ub(2)+ub(3)) )
%             
%             IoME = Ind(2) ;
%             
%         end
%         
%     elseif ( (IoME == 2) && (2*ub(IoME) < 0.1*(ub(1)+2*ub(2)+ub(3))) )
%         
%         IoME = Ind(2) ;
%         
%     end
    
%     if (IoME == 2)
%         
%         ub(IoME) = ub(IoME) - ply_dec/2 ;
%         
%     else
%         
%         ub(IoME) = ub(IoME) - ply_dec ;            
%                
%     end        
    
%     fprintf('    Refined number of plies =  ([ %6.1f %6.1f %6.1f ]s)  Total = %6.1f    ' , ub(1) , ub(2) , ub(3) , 2*(NN(1)+2*NN(2)+NN(3)) )
%     fprintf('\n');
%     fprintf('    ----------------------------------------');
    
% while end

% ub_1 = ub(1) ;
% ub_2 = ub(2) ;
% ub_3 = ub(3) ;

% fprintf('    The output of Lay_bnd subfunction = %6.3f  %6.3f  %6.3f ' , ub_1 , ub_2 , ub_3)
% fprintf('\n');
% 
%     input('The end of Lay_bnd mfile')

clear NN

end


