function popVar = initialize_pop(popsize, maxvar, lb_, ub_)
%% Initialize population variables

for i = 1 : popsize
    
    Cons = 1 ;     Cons_eq = 1 ;     W_limit = 0 ;      count_l = 0 ;
    i_i = i ;
    while ( (Cons > 0))% &&  (Cons_eq > 0) )
        
%         count_l = count_l + 1 ;
        
        % Virtual Constraints, Because for sum combinations of number of plies, constraints
        % are not satisfied even after several iterations, So W_limit set a little greater than 0.
        
%         if (count_l > 10000)            
%             W_limit = 0.000005*count_l ;
%         end
        
        popVar(i_i,1) = randsrc(1,1,[lb_(1) : ub_(1)]) ;  %  0.0 + (7.0 - 0.0) * rand ;

        popVar(i_i,2) = randsrc(1,1,[lb_(2) : ub_(2)]) ;

        popVar(i_i,3) = randsrc(1,1,[lb_(3) : ub_(3)]) ;

        for j = 4 : maxvar

            popVar(i_i,j) = -1 + 2*rand ;

        end
        
        [Con, Cons_eq] = nlcon_mo([popVar(i,1), popVar(i,2), popVar(i,3), popVar(i,4), popVar(i,5), popVar(i,6)]) ;
        
        Cons = max(Con, Cons_eq) ;
        
    end

    if (Cons_eq > 0)
        fprintf('\n');
        fprintf('initialize_pop line 39, Constraint was violated and a particle with ')
        fprintf('negative A or D matrix element has been selected as a feasible design point')
        fprintf('\n');
    end                
    
end

end

            
    
    
        
            
