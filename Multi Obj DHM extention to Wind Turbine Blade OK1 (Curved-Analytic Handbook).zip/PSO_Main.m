clc

clear all
% clearvars -except popVar_in

global w Inde  obj_num  w_dense  func  func_sqp  func_count  f_min  f_max  d1_bestg  d2_bestg  lb  ub  var_num  ...
    d1_bestp  v_old  Pbest  Gbest  pop_size   Gen_max   gen   Total_best_F_Comp   a_r  b_s  rho  th ...
    Pareto_sol  s1  func_count_PSO  func_count_SQP  func_count_sec_lev  p3  Global_var  i_glob  glob  ...
    Global_obj  Stack_Seque  N_x_crit

% rand('twister', 100);

% parpool('local',2)

% Gen_max = 5 ;   pop_size = 30 ;  % 300
Gen_max = 10 ;   pop_size = 120 ;  % 3600  Results of the paper was obtained with these settings
% Gen_max = 15 ;   pop_size = 60 ;    % 900

format short

tic

func = str2func('Wei_Buc_scnd') ;
func_sqp = str2func('Wei_Buc_scnd') ;

obj_num = 2 ;       var_num = 6 ;

inputs()

f_min = 5000*ones(1,obj_num) ;        f_max = zeros(1,obj_num) ;

Global_var = [] ;       i_glob = 0 ;    glob = 10*[1 2 3 4 5 6 7 8] ;

p2 = [] ;

s1 = 15 ;
s2 = 0 ;    % upper level spacing

func_count = 0 ;

def.popSize = obj_num ;

% [def.popSize,w] = direction_vector(s1, s2, obj_num) 

% lb = [0 ; 5 ; 4 ; -1 ; -1 ; -1];        % The number of 0, 45, and 90 degree layers is for one half of the laminate
% ub = [6 ; 9 ; 8 ;  1 ; 1  ;  1];      % Maximum Total number of layers could be: 2*(ub(1)+2*ub(2)+ub(3))

lb = [45 ; 25 ; 45 ; -1 ; -1 ; -1];
ub = [75 ; 40 ; 75 ;  1 ; 1  ;  1];

% lb = [74 ; 38 ; 15 ; -1 ; -1 ; -1];      % Obtained results for thesis The number of 0, 45, and 90 degree layers is for one half of the laminate
% ub = [78 ; 42 ; 19 ;  1 ; 1  ;  1];      % Maximum Total number of layers could be: 2*(ub(1)+2*ub(2)+ub(3))

% [ub_1 ub_2 ub_3] = Lay_bnd(ub) 

% input('PSO_Main.m, line 56')

min_layers = lb(1)+2*lb(2)+lb(3) ;
max_layers = ub(1)+2*ub(2)+ub(3) ;

for i = 1 : (max_layers-min_layers-4)
    
    w(i,1) = a_r*rho*b_s*2*(min_layers+i)*th ;
    
    w(i,2) = 1 ;
    
end

w_dense = w ;

popVar_in = initialize_pop(pop_size, var_num, lb, ub) ;

Pbest(1:pop_size,1:var_num) = popVar_in ;

for i_w = 1 : size(w,1)
    
%     w_dense(i_w,:) = w(i_w,:)./norm(w(i_w,:)) ;        
    Gbest(i_w,1:var_num) = popVar_in(1,1:var_num) ;
    
    d1_bestg(i_w) = 1000000 ;    
    d2_bestg(i_w) = 1000000 ;
    
end

di = 1 ;    w_dense = w_dense/di ;

% w_dense = w_dense./norm(w_dense) 

% w(i_w,:) = w(i_w,:)./norm(w(i_w,:)) ;

% input('PSO_Main.m, line 79')

for w_ind = 1 : 1 % size(w_dense,1)
    
    Inde = w_ind ;
    Total_best_F_Comp = 1000 ;        
    
    d1_bestp(1:pop_size) = 1000 ;
    d2_bestp(1:pop_size) = 1000 ;
    v_old(1:pop_size,1:var_num) = rand(pop_size,var_num) ;
    
    MSInd = 0 ;            % Multi-Start Index
    
%     I_sort = [1:1:pop_size] ;
    
    for gen = 1 : Gen_max
        MSInd = MSInd + 1 ;
%%                               Multi-Start Strategy

%             clearvars -except popVar_in  obj_num  pop_size  var_num  w_ind  gen  func  di  w_dense  Inde
            
            MSCrit = 200*(1-0.5*gen/Gen_max) ;
            
            if (gen < ceil(0.7*Gen_max))  &&  (MSInd > MSCrit)  &&  abs(bestgMS(gen-100)-bestgMS(gen-1)) < 0.1
                MSInd = 0 ;
                
                fprintf('\n --  Re-Initialization  --  --  Re-Initialization  --  --  Re-Initialization  -- \n')
                f_min = 500*ones(1,obj_num) ;        f_max = zeros(1,obj_num) ;
%                popVar = popVar_in ;
                
                popVar_MS = initialize_pop(pop_size, var_num, lb, ub) ;  %  rand(pop_size,var_num) ;
                
                Pbest(1:ceil(0.5*pop_size),1:var_num) = popVar_MS(1:ceil(0.5*pop_size),:) ; %1000 ;
                Gbest(w_ind,1:var_num) = popVar_MS(1,1:var_num) ; %1000 ;
                d1_bestg(w_ind) = 1000 ;
                d2_bestg(w_ind) = 1000 ;
                d1_bestp(1:pop_size) = 1000 ;
                d2_bestp(1:pop_size) = 1000 ;
                v_old(1:ceil(0.5*pop_size),1:var_num) = rand(ceil(0.5*pop_size),var_num) ;
            end
               
        
        
        omega = 0.7298 ; % 0.09 - (0.05)*(gen/Gen_max) ;
        
        x_old_in = popVar_in ;        
        
        [ popVar_in, I_sort ] = PSO_alg( x_old_in , omega , w_ind) ;
        
%         bestgMS(gen) = d1_bestg(w_ind) ;
        
%         if mod(gen , 15) == 0
%             
%             fprintf(' gen =  %5.0f       F_comp = %6.3f  ' , gen , d1_bestg(w_ind) ) 
%             
%             fprintf('\n---------------------------------  \n')
%         end
        
        figure(1)
        
        hold on
        
        
        for i_pl = 1 : size(Pareto_sol,1)
                
                if (2-Pareto_sol(i_pl,2) < 1)
                    
                    p2 = plot(Pareto_sol(i_pl,1), 2-Pareto_sol(i_pl,2),'o','LineWidth',1,...
                    'MarkerEdgeColor','k',... %                     'MarkerFaceColor','r',...
                    'MarkerSize',5) ;
                
                else
                    
                    if Pareto_sol(i_pl,1) ~= 0 || Pareto_sol(i_pl,2) ~= 0                                        
            
                        p1 = plot(Pareto_sol(i_pl,1), 2-Pareto_sol(i_pl,2),'o','LineWidth',0.9,...
                            'MarkerEdgeColor','g',...
                            'MarkerSize',6) ;
                        
                    end
                    
                end
                
                hold on
%             end
        end
        
%         xlim([400  1000])
        ylim([0.8  1.5])
        
        set(gca,'FontName','Times New Roman','FontSize',13) ;
        
        xlabel('weight (kg)','FontName','Times New Roman','FontSize',13)
        ylabel('\lambda (buckling factor)','FontName','Times New Roman','FontSize',13)
        
        grid on                        
        
        pause(0.01)
        
        fprintf(' ********************************* gen = ******************************  %5.0f        \n ' , gen  )
        
%         cont_ques = input('Enter 1 for continue and 0 for ending PSO') ;
        
%         if cont_ques == 0
            
%             break
            
%         end
        
    end
    
    
%     [f_val,g,x] = func(obj_num(1),X_Total(w_ind,1:var_num)) ;    
    
%     x_e(w_ind,:) = x ;
%     F_e(w_ind,:) = f_val ;   
    
    
%     fprintf('  norm(f_val) = %7.4f  \n' , norm(f_val) )
    
%     fprintf('  ------------------   END   ------------------   w_ind = %5.1f  \n' , w_ind )
    
end

Pareto_sol

% F_e
% 
% x_e

% fprintf('  ------------   PSO Finished   ------------  PSO_fun_count = %10.1f  \n'  ,  func_count)

% input('168')

hold on


cntr_f = 1 ;

for i_f = 1 : size(Pareto_sol,1)        % i_f: i_filter
    
    if Pareto_sol(i_f,1) ~= 0 || Pareto_sol(i_f,2) ~= 0
        
        Pareto_sol_f(cntr_f,:) = Pareto_sol(i_f,:) ;         % cntr_f: counter
        
        Gbest_f(cntr_f,:) = Gbest(i_f,:) ;
        
        cntr_f = cntr_f + 1 ;
        
    end
    
end

[Pareto_sol_f(:,1)   2-Pareto_sol_f(:,2)]

Gbest_f

input('PSO was finished, press any key to run SQP')

[x_e2, F_e2] = SQP_Run(w_dense, Pareto_sol_f, Gbest_f) ;     % Gbest are global best variables

x_e2

F_e2


for i_pl = 1 : size(F_e2,1)    
        
        if (2-F_e2(i_pl,2)) < 1
            
            p2 = plot(F_e2(i_pl,1), 2-F_e2(i_pl,2),'o','LineWidth',1,...
                'MarkerEdgeColor','k',... %                'MarkerFaceColor','r',...
                'MarkerSize',5) ;
            
        else
            
            p4 = plot(F_e2(:,1), 2-F_e2(:,2),'*b','LineWidth',1,... %        'MarkerEdgeColor','k',... %        'MarkerFaceColor','b',...
            'MarkerSize',5) ;
            
        end
        
        %                 plot(Pareto_sol(i_pl,1), Pareto_sol(i_pl,2), 'bo')                
        hold on
end

ylim([0.8  1.5])
        
if isempty(p2)
    
    legend([p3 p4],'Feasible points','Pareto-optimal','Location','northwest')
    
else
    
    legend([p2 p3 p4],'Infeasible points','Feasible points','Pareto-optimal','Location','northwest')
    
end

fprintf('\n  Global best objectives and correspondigng variables (After PSO & SQP first level): \n ' )

glob

%% Second level (PSO)    
    
% for i_sec = 1 : size(F_e2,1)
%     
%     clear Stack_Sequ  landa_sec
%     
%     [Stack_Sequ, landa_sec] = sec_level(1, x_e2(i_sec,:)) ;    % Wei_Buc_scnd(obj_num,Gbest_f(i_pso,:)) ;
%     
%     Stack_Seque(i_sec,1) = size(Stack_Sequ,2) ;
%     Stack_Seque(i_sec,2:1+size(Stack_Sequ,2)) = Stack_Sequ ;
%     
% %     landa_seco(i_sec,1) = size(Stack_Sequ,2) ;
%     landa_seco(i_sec,1) = 2-landa_sec ;
%     landa_seco
% 
% % input('354')
%     
% end
% 
% Stack_Seque
% landa_seco

% fprintf('\n    First   and   Second level for pso results: ' )

% [1000*Pareto_sol_f(:,1)  2-Pareto_sol_f(:,2)   Gbest_f_pso_sec] 



legend('show') % makes the legend in the current axes visible. If a legend does not exist, then MATLAB� creates one using the default strings.

% [GD_SQP, Delta_SQP, MSP_SQP, IGD_SQP] = Perf_criteria(F_e2, PF_star_IGD) ;

% F_e2-PF_star_IGD

fprintf('\n N.o.layers  Weight(kg) ' )

Num_lay_w = [2*(min_layers+[1:size(w,1)]')   w(:,1)] 

fprintf('\n                                 PSO        SQP   Second level   Total   \n')

% fprintf('\n    Generational Distance (GD)             %5.4f    %6.5f  \n' , GD_PSO , GD_SQP )

% fprintf('\n    Spread (Delta)                         %5.4f    %6.5f  \n' , Delta_PSO , Delta_SQP )

% fprintf('\n    Maximum Spread                         %5.4f    %6.5f  \n' , MSP_PSO , MSP_SQP )

% fprintf('\n    Inverted Generational Distance(IGD)    %5.4f    %6.5f  \n' , IGD_PSO , IGD_SQP )

fprintf('\n  Function Evaluations =     %7.0f    %7.0f    %7.0f    %7.0f    \n\n' , func_count_PSO , func_count_SQP, size(F_e2,1)*func_count_sec_lev, ...
    (func_count_PSO+func_count_SQP+size(F_e2,1)*func_count_sec_lev)  )

 
% Added 98-4-6
figure(2)

[Global_obj_sorted IndstrG] = sortrows(Global_obj) ;

ico = 1 ;

for i = size(Global_obj_sorted,1) : -1 : 2
    
    if 2-Global_obj_sorted(i,2) < 1
        
        p2 = plot(Global_obj_sorted(i,1), 2-Global_obj_sorted(i,2),'o','LineWidth',0.9,...
                    'MarkerEdgeColor','k',...
                    'MarkerSize',6) ;
        
        hold on
        
        grid on
        
    else
        
        p3 = plot(Global_obj_sorted(i,1), 2-Global_obj_sorted(i,2),'o','LineWidth',0.9,...
                'MarkerEdgeColor','g',...
                'MarkerSize',6) ;
            
            hold on
            
            if i > 1
                
                if abs(Global_obj_sorted(i,1) - Global_obj_sorted(i-1,1)) > 0.01
                                        
                    p1 = plot(Global_obj_sorted(i,1), 2-Global_obj_sorted(i,2),'*b','LineWidth',1,...
                        'MarkerSize',6) ;
                        
                    hold on
                    
                    x_e2_crt(ico,:) = Global_var(IndstrG(i),:) ;
                    
                    F_e2_crt(ico,:) = Global_obj(IndstrG(i),:) ;
                    
                    Stack_Seque_F_e2_crt(ico,:) = Stack_Seque(IndstrG(i),:) ;
                    
                    ico = ico + 1 ;
                    
                end
                
            end
            
    end
    
end

ylim([0.8  1.5])
        
x_e2_crt(size(x_e2_crt,1):-1:1 , : ) = x_e2_crt(1:size(x_e2_crt,1) , : )

F_e2_crt(size(F_e2_crt,1):-1:1 , : ) = F_e2_crt(1:size(F_e2_crt,1) , : )

Stack_Seque_F_e2_crt(size(Stack_Seque_F_e2_crt,1):-1:1 , : ) = Stack_Seque_F_e2_crt(1:size(Stack_Seque_F_e2_crt,1) , : )

set(gca,'FontName','Times New Roman','FontSize',11,'FontWeight','Bold') ;
        
xlabel('weight (kg)','FontName','Times New Roman','FontSize',12,'FontWeight','Bold')
ylabel('\lambda (buckling factor)','FontName','Times New Roman','FontSize',12,'FontWeight','Bold')
        
if isempty(p2)
    
    legend([p3 p4],'Feasible points','Pareto-optimal','Location','northwest')
    
else
    
    legend([p2 p3 p4],'Infeasible points','Feasible points','Pareto-optimal','Location','northwest')
    
end

% save('Results_TwoObjective_curved_98_3_3.mat','Stack_Seque_Pareto','Stack_Seque_SQP','Gbest_f','Pareto_sol_f','x_e2','F_e2','func_count_PSO','func_count_SQP','Global_var','Global_obj','Stack_Seque')
save('Results_TwoObjective_curved_98_4_9_Panel3.mat','Gbest_f','Pareto_sol_f','x_e2','F_e2','func_count_PSO','func_count_SQP','Global_var','Global_obj','Stack_Seque','Stack_Seque_F_e2')

% load('Results_TwoObjective_curved_98_3_12.mat')


%%            Sub-Functions

function [n,w] = direction_vector(s1,s2,m)
[n,w] = gen_weight(s1,m);
if s2 > 0
    [n2,w2] = gen_weight(s2,m);
    n = n+n2;
    w = [w;w2*0.5+(1 - 0.5)/(m)];
end
return
end

% Generating the direction vectors
function [n,w]=gen_weight(p,M)
NumPoints((1:M-1))=p;
% partitioned into the first objective
Beta1 = (0:(NumPoints(1)))'/(NumPoints(1));
Beta = Beta1;
for i = 2:M-1
    ki = round((1-sum(Beta1,2))*(NumPoints(i)));
    Beta = [];
    for j =1:size(Beta1,1)
        BetaVec = (0:ki(j))'/(NumPoints(i));
        Beta = [Beta; [repmat(Beta1(j,:), length(BetaVec),1) BetaVec] ];
    end
    Beta1 = Beta;
end
w= [Beta (1 - sum(Beta1,2))]; 
n=size(w,1);
return
end


