function [sigma_SQP, popVar_out_SQP] = SQP_Run_Curved_3(lambda_in, alpha_in, beta_in)


x0_curved(1:3) = [lambda_in, alpha_in, beta_in] 

lb_sqp_Curved = [0 -30  -30] ; %  x0 - 1 ;   %  zeros(1,size(x0,2)) ; % [0 0 0 0 0 0 0] ; %  
% lb_sqp(1) = 0.00001 ;

ub_sqp_Curved = x0_curved + 29 ;   %  ones(1,size(x0,2)) ; %  [1 1 1 1 1 1 1] ; % 

%         for ii = 1 : 3
%             if lb_sqp(ii)<lb(ii) 
%                 lb_sqp(ii) = lb(ii) ;
%             end
%             
%             if ub_sqp(ii) > ub(ii)
%                 ub_sqp(ii) = ub(ii) ;
%             end
%             
%         end

% parpool('local',2)

% sched = findResource('scheduler','type','local');
% job1 = batch(sched, @myfmincon, 1, {x1,c1}, 'Matlabpool',3);
% job2 = batch(sched, @myfmincon, 1, {x2,c2}, 'Matlabpool',3);
% wait(job1);
% wait(job2);
% xx1 = getAllOutputArguments(job1);
% xx2 = getAllOutputArguments(job2);

options = optimset('LargeScale','off' , 'Algorithm' , 'sqp' , 'MaxIter',1000,'MaxFunEvals',30000,...
                   'TolFun',1e-8,'TolX',1e-7,'TolCon',1e-4,'Diagnostics','off','Display','off') ;   % ,'UseParallel','always'
    
[x_x ,FVAL,EXITFLAG,OUTPU] = fmincon(@Obj_buc_Curved_4,x0_curved,[],[],[],[],lb_sqp_Curved,ub_sqp_Curved,[], options) ;

%         bfval(w_ind,:) = f_val ;
        
sigma_SQP = FVAL ;
        
popVar_out_SQP(1:3) = x_x ;






