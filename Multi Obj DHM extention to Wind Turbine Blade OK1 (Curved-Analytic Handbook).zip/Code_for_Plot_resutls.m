


figure(2)

for i = 1 : size(Global_obj,1)
    
    if 2-Global_obj(i,2) < 1
        
        p2 = plot(1000*Global_obj(i,1), 2-Global_obj(i,2),'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...
                    'MarkerSize',5) ;
                
        hold on
                
    else
        
        flagg = 0 ;
        
        for j = 1 : size(F_e2,1)
            
            if abs(Global_obj(i,:)-F_e2(j,:)) < 0.0001
                
                flagg = 1 ;
                
                Stack_Seque_F_e2(j,:) = Stack_Seque(i,:) ;
                    
            end
            
        end
        
        if flagg == 1
            
            p1 = plot(1000*Global_obj(i,1), 2-Global_obj(i,2),'*b','LineWidth',1,...
                        'MarkerSize',5) ;
                    
            hold on
                    
        else
            
            p3 = plot(1000*Global_obj(i,1), 2-Global_obj(i,2),'o','LineWidth',1,...
                'MarkerEdgeColor','g',...
                'MarkerSize',5) ;
            
            hold on
            
        end
                
    end
    
    grid on
    
end

if isempty(p2)
    
    legend([p3 p4],'Feasible points','Pareto-optimal','Location','northwest')
    
else
    
    legend([p2 p3 p4],'Infeasible points','Feasible points','Pareto-optimal','Location','northwest')
    
end


